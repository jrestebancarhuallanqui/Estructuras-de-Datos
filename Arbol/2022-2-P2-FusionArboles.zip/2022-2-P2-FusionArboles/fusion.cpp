#include <iostream>
#include "ArbolBB.h"
#include "funcionesAB.h"
#include "funcionesABB.h"
using namespace std;

struct NodoArbol * c_crearNuevoNodo(struct NodoArbol * izquierda,
        int elemento, int cantidad, struct NodoArbol * derecha) {

    struct NodoArbol * nuevo = new struct NodoArbol;
    nuevo->derecha = derecha;
    nuevo->izquierda = izquierda;
    nuevo->elemento = elemento;
    nuevo->cantidad = cantidad;
    return nuevo;
}

void c_plantarArbolBinario(struct NodoArbol *& raiz, struct NodoArbol * izquierda, 
                         int elemento, int cantidad, struct NodoArbol * derecha) {
    
    struct NodoArbol * nuevoNodo = c_crearNuevoNodo(izquierda, elemento, cantidad, derecha);
    raiz = nuevoNodo;
}

void c_insertarRecursivo(struct NodoArbol *& raiz, int elemento, int cantidad){
    if(esNodoVacio(raiz))
        c_plantarArbolBinario(raiz, nullptr, elemento, cantidad, nullptr);
    else
        if(raiz->elemento > elemento)
            c_insertarRecursivo(raiz->izquierda, elemento, cantidad);
        else
            if(raiz->elemento < elemento)
                c_insertarRecursivo(raiz->derecha, elemento, cantidad);
            else
                cout << "El elemento " << elemento << "Ya se encuentra en el árbol" << endl;
}

void c_insertar(struct ArbolBinarioBusqueda & arbol, int elemento, int cantidad){
    c_insertarRecursivo(arbol.arbolBinario.raiz, elemento, cantidad);
}

void c_inorder_rec(struct NodoArbol * nodo){
     if (not esNodoVacio(nodo)){
        c_inorder_rec(nodo->izquierda);
        cout<<"("<<nodo->elemento<<" - "<<nodo->cantidad<<") ";
        c_inorder_rec(nodo->derecha);
    }
}

void c_inorder(struct ArbolBinarioBusqueda & arbol){
    c_inorder_rec(arbol.arbolBinario.raiz);
}

void c_insertar(struct NodoArbol *& raiz, struct NodoArbol *& emisor){
     if(esNodoVacio(raiz))
        raiz = emisor;
    else
        if(raiz->elemento > emisor->elemento)
            c_insertar(raiz->izquierda, emisor);
        else
            if(raiz->elemento < emisor->elemento)
                c_insertar(raiz->derecha, emisor);
            else
            {
                raiz->cantidad = raiz->cantidad + emisor->cantidad;
                delete emisor;//liberar nodo
            }
}

void c_fusionar_rec(struct NodoArbol *& destino, struct NodoArbol *& emisor){
    //caso base
    if(esNodoVacio(emisor)) return;
    //caso recursivo
    //llamadas recursivas
    c_fusionar_rec(destino, emisor->izquierda);
    c_fusionar_rec(destino, emisor->derecha);
    //procesar nodo
    NodoArbol* nodoActual = emisor;
    emisor = nullptr;//Desconectar del arbol
    c_insertar(destino, nodoActual);
}

void c_fusionar(struct ArbolBinarioBusqueda & destino, struct ArbolBinarioBusqueda & emisor){
    c_fusionar_rec(destino.arbolBinario.raiz, emisor.arbolBinario.raiz);
}

int main(int argc, char** argv) {
    struct ArbolBinarioBusqueda arbol1, arbol2;
    construir(arbol1);
    construir(arbol2);
    //insertar en arbol1
    c_insertar(arbol1, 20170620, 20);
    c_insertar(arbol1, 20170810, 20);
    c_insertar(arbol1, 20180211, 20);
    c_insertar(arbol1, 20180409, 10);
    //insertar en arbol2
    c_insertar(arbol2, 20170811, 5);
    c_insertar(arbol2, 20180211, 10);
    c_insertar(arbol2, 20180410, 15);
    
    cout<<"Arbol 1:\n";
    c_inorder(arbol1); cout<<endl;
    cout<<"Arbol 2:\n"; 
    c_inorder(arbol2);cout<<endl;
    
    cout<<"\nFusionar arboles:\n";
    c_fusionar(arbol1, arbol2);
    
    cout<<"Arbol 1 despues de fusionar:\n";
    c_inorder(arbol1); cout<<endl;//todos los elementos mezclados
    cout<<"Arbol 2 despues de fusionar:\n"; 
    c_inorder(arbol2);cout<<endl;//vacio
    
    
    return 0;
}


/* 
 * File:   ArbolB.h
 * Author: ANA RONCAL
 *
 * Created on 27 de octubre de 2024, 17:00
 */

#ifndef ARBOLB_H
#define ARBOLB_H

#include "NodoArbol.h"

struct ArbolBinario{
    struct NodoArbol * raiz;
};

#endif /* ARBOLB_H */